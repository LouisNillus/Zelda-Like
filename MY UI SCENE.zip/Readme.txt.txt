Salut Manu !

Dans la scene d'UI, il faut que tu actives l'audio source et que tu d�satives le GameObject parent "Abilities"

A bient�t !


Le stagiaire caf�.