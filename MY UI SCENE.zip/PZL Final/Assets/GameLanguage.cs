﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class GameLanguage
{

    public static Language lang = Language.french;



}

public enum Language
{
    french,
    english,
}